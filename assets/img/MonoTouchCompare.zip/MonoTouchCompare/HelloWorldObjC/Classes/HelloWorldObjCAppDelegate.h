//
//  HelloWorldObjCAppDelegate.h
//  HelloWorldObjC
//
//  Created by Scott Densmore on 10/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloWorldObjCAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	UIButton *button;
	UILabel *label;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UIButton *button;
@property (nonatomic, retain) IBOutlet UILabel *label;

- (IBAction)sampleTap:(id)sender;
@end

