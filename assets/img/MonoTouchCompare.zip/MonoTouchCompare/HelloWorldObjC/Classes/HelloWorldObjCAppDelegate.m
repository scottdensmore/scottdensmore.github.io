//
//  HelloWorldObjCAppDelegate.m
//  HelloWorldObjC
//
//  Created by Scott Densmore on 10/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "HelloWorldObjCAppDelegate.h"

@implementation HelloWorldObjCAppDelegate

@synthesize window;
@synthesize button;
@synthesize label;

- (IBAction)sampleTap:(id)sender {
	[label setText:@"Second button clicked"];
}

- (void)buttonEvent:(id)sender {
	static int count = 0;
	[label setText:[NSString stringWithFormat:@"I have been tapped %d times.", count++]];
}

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

	[button addTarget:self action:@selector(buttonEvent:) forControlEvents:UIControlEventTouchDown];
    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
	[button release];	
	[label release];
    [super dealloc];
}


@end
