//
//  NewsArticleParser.h
//  RSSReader
//
//  Created by Scott Densmore on 10/17/09.
//  Copyright 2009 Scott Densmroe. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NewsArticle;
@protocol NewsArticleParserDelegate;

@interface NewsArticleParser : NSObject {
	NewsArticle *currentNewsArticle;
	NSMutableString *propertyValue;
	id<NewsArticleParserDelegate> delegate;
	NSOperationQueue *retrieverQueue;
}

+ (id)newNewsArticleParser;

@property(nonatomic, assign) id<NewsArticleParserDelegate> delegate;

- (void)parseNewsArticles;
@end

@protocol NewsArticleParserDelegate <NSObject>

- (void)addNewsArticle:(NewsArticle *)newsArticle;
- (void)parserFinished;

@end


