//
//  NewsArticle.h
//  RSSReader
//
//  Created by Scott Densmore on 10/17/09.
//  Copyright 2009 Scott Densmroe. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NewsArticle : NSObject {
	NSString *headline;
	NSString *content;
}

@property (nonatomic, copy) NSString *headline;
@property (nonatomic, copy) NSString *content;
@end
