//
//  RootViewController.h
//  RSSReader
//
//  Created by Scott Densmore on 10/17/09.
//  Copyright Scott Densmroe 2009. All rights reserved.
//

#import "NewsArticleParser.h"
@class DetailsViewController;

@interface NewsArticleViewController : UITableViewController <NewsArticleParserDelegate> {
	NSMutableArray *newsArticles;
	UITableView *newsArticleTableView;
	DetailsViewController *detailsView;
}

@property (nonatomic, retain) IBOutlet UITableView *newsArticleTableView;
@property (nonatomic, retain) IBOutlet DetailsViewController *detailsView;

@end
