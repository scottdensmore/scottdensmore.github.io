//
//  NewsArticle.m
//  RSSReader
//
//  Created by Scott Densmore on 10/17/09.
//  Copyright 2009 Scott Densmroe. All rights reserved.
//

#import "NewsArticle.h"


@implementation NewsArticle

@synthesize headline;
@synthesize content;

@end
