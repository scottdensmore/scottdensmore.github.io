//
//  NewsArticleParser.m
//  RSSReader
//
//  Created by Scott Densmore on 10/17/09.
//  Copyright 2009 Scott Densmroe. All rights reserved.
//

#import "NewsArticleParser.h"
#import "NewsArticle.h"

@implementation NewsArticleParser

@synthesize delegate;

+ (id)newNewsArticleParser {
	return [[[self class] alloc] init];
}

#pragma mark -
#pragma mark Memory Management

- (id) init {
	self = [super init];
	if (self != nil) {
		retrieverQueue = [[NSOperationQueue alloc] init];
		retrieverQueue.maxConcurrentOperationCount = 1;
	}
	return self;
}

- (void) dealloc {
	self.delegate = nil;
	[retrieverQueue release];
	[super dealloc];
}

#pragma mark -
#pragma mark Instance Mathods

- (void)parseNewsArticles {
	SEL method = @selector(parseForData);
	NSInvocationOperation *op = [[NSInvocationOperation alloc] initWithTarget:self 
																	 selector:method 
																	   object:nil];
	[retrieverQueue addOperation:op];
	[op release];
}

#pragma mark -
#pragma mark NSXMLParserDelegate

static NSString *feedURLString = @"http://newsrss.bbc.co.uk/rss/sportonline_world_edition/football/teams/t/tottenham_hotspur/rss.xml";

- (BOOL)parseForData {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	NSURL *url = [NSURL URLWithString:feedURLString];
	BOOL success = NO;
	NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:url];
	[parser setDelegate:self];
	[parser setShouldProcessNamespaces:NO];
	[parser setShouldReportNamespacePrefixes:NO];
	[parser setShouldResolveExternalEntities:NO];
	success = [parser parse];
	NSError *parseError = [parser parserError];
	if (parseError) {
		NSLog(@"parse error = %@", parseError);
	}
	[parser release];
	[pool drain];
	return success;
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
	[(id)[self delegate] performSelectorOnMainThread:@selector(parserFinished)
										  withObject:nil
									   waitUntilDone:NO];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	[self autorelease];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
    attributes:(NSDictionary *)attributeDict {
	if(nil != qName) {
		elementName = qName; // swap for the qName if we have a name space
	}
	
	if ([elementName isEqualToString:@"item"]) {
		currentNewsArticle = [[[NewsArticle alloc] init] autorelease];
	} 
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	if (!propertyValue) {
		propertyValue = [[NSMutableString alloc] initWithString:string];
	} else {
		[propertyValue appendString:string];
	}
	
	NSLog(@"Processing Value: %@", propertyValue);
	
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {     
	if (qName) {
		elementName = qName; // switch for the qName
	}
	
	if ([elementName isEqualToString:@"title"]) {
		currentNewsArticle.headline = propertyValue;
	} else if ([elementName isEqualToString:@"description"]) {
		currentNewsArticle.content = propertyValue;
	} 
	else if([elementName isEqualToString:@"item"]) {
		[(id)[self delegate] performSelectorOnMainThread:@selector(addNewsArticle:)
											  withObject:currentNewsArticle
										   waitUntilDone:NO];
	}
	[propertyValue release];
	propertyValue = nil;
}

- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
	if(parseError.code != NSXMLParserDelegateAbortedParseError) {
		NSLog(@"parser error %@, userInfo %@", parseError, [parseError userInfo]);
	}
}

@end
