//
//  RootViewController.m
//  RSSReader
//
//  Created by Scott Densmore on 10/17/09.
//  Copyright Scott Densmroe 2009. All rights reserved.
//

#import "NewsArticleViewController.h"
#import "NewsArticle.h";
#import "NewsArticleParser.h"
#import "DetailsViewController.h"

@implementation NewsArticleViewController

@synthesize newsArticleTableView;
@synthesize detailsView;

#pragma mark -
#pragma mark View methods

- (void)viewDidLoad {
    [super viewDidLoad];
	newsArticles = [[NSMutableArray alloc] init];
	NewsArticleParser *parser = [NewsArticleParser newNewsArticleParser];
	parser.delegate = self;
	[parser parseNewsArticles];
}

#pragma mark -
#pragma mark NewsArticleParserDelegate methods

- (void)addNewsArticle:(NewsArticle *)newsArticle {
	[newsArticles addObject:newsArticle];
}

- (void)parserFinished {
	[newsArticleTableView reloadData];
}

#pragma mark -
#pragma mark TableView methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [newsArticles count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
	NewsArticle *newsArticle = [newsArticles objectAtIndex:indexPath.row];
	cell.textLabel.text = newsArticle.headline;
    return cell;
}


// Override to support row selection in the table view.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	detailsView.newsArticle = [newsArticles objectAtIndex:indexPath.row];
	[self.navigationController pushViewController:detailsView animated:YES];
}

#pragma mark -
#pragma mark Memory management

- (void)dealloc {
	[detailsView release];
	[newsArticles release];
	[newsArticleTableView release];
    [super dealloc];
}


@end

