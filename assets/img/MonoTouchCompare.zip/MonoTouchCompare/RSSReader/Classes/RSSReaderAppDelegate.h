//
//  RSSReaderAppDelegate.h
//  RSSReader
//
//  Created by Scott Densmore on 10/17/09.
//  Copyright Scott Densmroe 2009. All rights reserved.
//

@interface RSSReaderAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end

