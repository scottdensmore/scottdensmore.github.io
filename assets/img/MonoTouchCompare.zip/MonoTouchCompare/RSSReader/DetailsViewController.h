//
//  DetailsViewController.h
//  RSSReader
//
//  Created by Scott Densmore on 10/18/09.
//  Copyright 2009 Scott Densmroe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NewsArticle;

@interface DetailsViewController : UIViewController {
	UITextView *textView;
	NewsArticle *newsArticle;
}

@property (nonatomic, retain) IBOutlet UITextView *textView;
@property (nonatomic, retain) NewsArticle *newsArticle;

@end
