//
//  DetailsViewController.m
//  RSSReader
//
//  Created by Scott Densmore on 10/18/09.
//  Copyright 2009 Scott Densmroe. All rights reserved.
//

#import "DetailsViewController.h"
#import "NewsArticle.h";

@implementation DetailsViewController

@synthesize textView;
@synthesize newsArticle;

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.navigationItem.title = newsArticle.headline;
	textView.text = newsArticle.content;
}

- (void)dealloc {
	[textView release];
	[newsArticle release];
    [super dealloc];
}


@end
