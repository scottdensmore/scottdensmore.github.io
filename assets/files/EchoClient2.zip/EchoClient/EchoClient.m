#import <Foundation/Foundation.h>
#import "ReservationService.h"
#import "WSGuest.h"
#import "WSSearchAvailibiltyRequest.h"
#import "WSResort.h"

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

    NSLog(@"Calling reservation service: RetrieveGuest");
	id result = [ReservationService RetrieveGuest:[NSNumber numberWithInt:1] ]; 
	NSLog(@"Result: %@", result);
	WSGuest *guest = [[WSGuest alloc] initWithDictionary:result];
	NSLog(@"Id: %d", [guest id]);
	NSLog(@"FirstName: %@", [guest firstName]);
	NSLog(@"LastName: %@", [guest lastName]);
	
	NSLog(@"Calling reservation service: SearchAvailibilty");
	WSSearchAvailibiltyRequest *searchAvailibiltyReqeust = [[WSSearchAvailibiltyRequest alloc] init];
	[searchAvailibiltyReqeust setArrival:[NSDate date]];
	[searchAvailibiltyReqeust setDeparture:[NSDate date]];
	[searchAvailibiltyReqeust setNumberOfAdults:2];
	[searchAvailibiltyReqeust setNumberOfChildren:2];
	result = [ReservationService SearchAvailibilty:[searchAvailibiltyReqeust dictionary]];
	NSLog(@"Result from SearchAvailibilty: %@", result);
	NSArray *resortCollection = [(NSDictionary*)result objectForKey:@"Resort"];
	NSDictionary  *resortDictionary;
	for (resortDictionary in resortCollection) {
		WSResort *resort = [[WSResort alloc] initWithDictionary:resortDictionary];
		NSLog(@"Resort Id: %d", [resort id]);
		NSLog(@"Resort Name: %@", [resort name]);
	}
	
	[pool drain];
    return 0;
}
