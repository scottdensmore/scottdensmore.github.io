//
//  WSSearchAvailibiltyRequest.h
//  EchoClient
//
//  Created by Scott Densmore on 10/8/08.
//  Copyright 2008 Scott Densmore. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface WSSearchAvailibiltyRequest : NSObject {
	NSMutableDictionary *resultDictionary;
}

-(id)initWithDictionary:(NSDictionary *)dictionary;
-(NSDictionary *)dictionary;
-(NSDate *)arrival;
-(void)setArrival:(NSDate *)date;
-(NSDate *)departure;
-(void)setDeparture:(NSDate *)date;
-(int)numberOfChildren;
-(void)setNumberOfChildren:(int)count;
-(int)numberOfAdults;
-(void)setNumberOfAdults:(int)count;
@end
