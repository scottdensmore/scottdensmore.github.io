//
//  WSGuest.m
//  EchoClient
//
//  Created by Scott Densmore on 10/1/08.
//  Copyright 2008 Scott Densmore. All rights reserved.
//

#import "WSGuest.h"


@implementation WSGuest
-(id)initWithDictionary:(NSDictionary *)dictionary 
{
	self = [super init];
	resultDictionary = [[dictionary mutableCopy] retain];
	[resultDictionary setObject:@"http://scottdensmore.com/reservations/2008/09" forKey:(NSString *)kWSRecordNamespaceURI];
	[resultDictionary setObject:@"Guest" forKey:(NSString *)kWSRecordType];
	return self;
}

-(void)dealloc
{
	[resultDictionary release];
	[super dealloc];
}

-(NSDictionary *)dictionary 
{
	return resultDictionary;
}

-(int)id
{
	NSString *value = [resultDictionary objectForKey:@"Id"];

	return [value intValue];
}

-(NSString *)firstName 
{
	return [resultDictionary objectForKey:@"FirstName"];
}

-(NSString *)lastName 
{
	return [resultDictionary objectForKey:@"LastName"];
}
@end
