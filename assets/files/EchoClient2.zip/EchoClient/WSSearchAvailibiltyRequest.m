//
//  WSSearchAvailibiltyRequest.m
//  EchoClient
//
//  Created by Scott Densmore on 10/8/08.
//  Copyright 2008 Scott Densmore. All rights reserved.
//

#import "WSSearchAvailibiltyRequest.h"


@implementation WSSearchAvailibiltyRequest
-(id)init
{
	return [self initWithDictionary:[NSDictionary dictionaryWithObjectsAndKeys:
			 @"", @"Arrival",
			 @"", @"Departure", 
			 @"", @"NumberOfAdults",
			 @"", @"NumberOfChildren",
			 nil]];
}

-(id)initWithDictionary:(NSDictionary *)dictionary 
{
	self = [super init];
	resultDictionary = [[dictionary mutableCopy] retain];
	[resultDictionary setObject:@"http://scottdensmore.com/reservations/2008/09" forKey:(NSString *)kWSRecordNamespaceURI];
	[resultDictionary setObject:@"SearchAvailibiltyRequest" forKey:(NSString *)kWSRecordType];
	[resultDictionary setObject:[[NSArray alloc] initWithObjects:@"Arrival", @"Departure", @"NumberOfAdults", @"NumberOfChildren", nil]  
						 forKey:(NSString *)kWSRecordParameterOrder];
	return self;
}

-(void)dealloc
{
	[resultDictionary release];
	[super dealloc];
}

-(NSDictionary *)dictionary 
{
	return resultDictionary;
}

-(NSDate *)arrival
{
	NSDate *value = [NSDate dateWithString: [resultDictionary objectForKey:@"Arrival"]];
	
	return value;
}

-(void)setArrival:(NSDate *)date
{	
	[resultDictionary setObject:date forKey:@"Arrival"];
}

-(NSDate *)departure 
{
	return [resultDictionary objectForKey:@"Departure"];
}

-(void)setDeparture:(NSDate *)date
{
	[resultDictionary setObject:date forKey:@"Departure"];
}

-(int)numberOfChildren 
{
	NSNumber *val = [resultDictionary objectForKey:@"NumberOfChildren"];
	return [val intValue];
}

-(void)setNumberOfChildren:(int)count
{
	[resultDictionary setObject:[NSNumber numberWithInt:count] forKey:@"NumberOfChildren"];
}

-(int)numberOfAdults 
{
	NSNumber *val = [resultDictionary objectForKey:@"NumberOfAdults"];
	return [val intValue];
}


-(void)setNumberOfAdults:(int)count;
{
	[resultDictionary setObject:[NSNumber numberWithInt:count] forKey:@"NumberOfAdults"];
}
@end
