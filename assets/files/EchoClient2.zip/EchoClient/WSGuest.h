//
//  WSGuest.h
//  EchoClient
//
//  Created by Scott Densmore on 10/1/08.
//  Copyright 2008 Scott Densmore. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface WSGuest : NSObject {
	NSMutableDictionary *resultDictionary;
}

-(id)initWithDictionary:(NSDictionary *)dictionary;
-(NSDictionary *)dictionary;
-(int)id;
-(NSString *)firstName;
-(NSString *)lastName;
@end
