//
//  WSResort.m
//  EchoClient
//
//  Created by Scott Densmore on 10/13/08.
//  Copyright 2008 Scott Densmore. All rights reserved.
//

#import "WSResort.h"


@implementation WSResort
-(id)initWithDictionary:(NSDictionary *)dictionary 
{
	self = [super init];
	resultDictionary = [[dictionary mutableCopy] retain];
	[resultDictionary setObject:@"http://scottdensmore.com/reservations/2008/09" forKey:(NSString *)kWSRecordNamespaceURI];
	[resultDictionary setObject:@"Resort" forKey:(NSString *)kWSRecordType];
	return self;
}

-(void)dealloc
{
	[resultDictionary release];
	[super dealloc];
}

-(NSDictionary *)dictionary 
{
	return resultDictionary;
}

-(int)id
{
	NSNumber *value = [resultDictionary objectForKey:@"Id"];
	
	return [value intValue];
}

-(NSString *)name 
{
	return [resultDictionary objectForKey:@"Name"];
}

@end
