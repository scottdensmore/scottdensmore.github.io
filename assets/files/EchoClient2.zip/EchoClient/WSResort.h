//
//  WSResort.h
//  EchoClient
//
//  Created by Scott Densmore on 10/13/08.
//  Copyright 2008 Scott Densmore. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface WSResort : NSObject {
	NSMutableDictionary *resultDictionary;
}

-(id)initWithDictionary:(NSDictionary *)dictionary;
-(int)id;
-(NSString *)name;
@end
