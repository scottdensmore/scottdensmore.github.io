﻿namespace ContinuationSpike
{
    using System;
    using System.Configuration;
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.ServiceRuntime;

    public class CloudConfiguration
    {
        public static CloudStorageAccount GetStorageAccount()
        {
            const string settingName = "DataConnectionString";
            try
            {
                var account = CloudStorageAccount.FromConfigurationSetting(settingName);
                if (account == null)
                {
                    SetConfigurationSettingPublisher();
                    account = CloudStorageAccount.FromConfigurationSetting(settingName);
                }

                return account;
            }
            catch (InvalidOperationException)
            {
                SetConfigurationSettingPublisher();
                return CloudStorageAccount.FromConfigurationSetting(settingName);
            }
        }

        private static void SetConfigurationSettingPublisher()
        {
            CloudStorageAccount.SetConfigurationSettingPublisher((configName, configSetter) =>
                                                                     {
                                                                         string value = ConfigurationManager.AppSettings[configName];
                                                                         if (RoleEnvironment.IsAvailable)
                                                                         {
                                                                             value = RoleEnvironment.GetConfigurationSettingValue(configName);
                                                                         }

                                                                         configSetter(value);
                                                                     });
        }
    }
}