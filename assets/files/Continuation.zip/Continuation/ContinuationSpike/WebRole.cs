using System.Linq;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace ContinuationSpike
{
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;

    public class WebRole : RoleEntryPoint
    {
        public override bool OnStart()
        {
            DiagnosticMonitor.Start("DiagnosticsConnectionString");

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.
            RoleEnvironment.Changing += RoleEnvironmentChanging;
            ApplicationStorageInitializer.Initialize();
            return base.OnStart();
        }

        private void RoleEnvironmentChanging(object sender, RoleEnvironmentChangingEventArgs e)
        {
            // If a configuration setting is changing
            if (e.Changes.Any(change => change is RoleEnvironmentConfigurationSettingChange))
            {
                // Set e.Cancel to true to restart this role instance
                e.Cancel = true;
            }
        }

        public static class ApplicationStorageInitializer
        {
            public static void Initialize()
            {
                CloudStorageAccount account = CloudConfiguration.GetStorageAccount();

                // Tables
                /// The tables for the ExpenseDataContext are created manually in order to choose the table name.
                /// Calling CloudTableClient.CreateTablesFromModel creates 1 table for each IQueryable property
                /// in the class ExpenseDataContext and the table name, by default, is set to the property name:
                ///   CloudTableClient.CreateTablesFromModel(typeof(ExpenseDataContext), account.TableEndpoint.ToString(), account.Credentials);
                var cloudTableClient = new CloudTableClient(account.TableEndpoint.ToString(), account.Credentials);
                cloudTableClient.CreateTableIfNotExist(MessageContext.MessageTable);
            }
        }
    }
}
