namespace ContinuationSpike
{
    using System.Collections;
    using Microsoft.WindowsAzure.StorageClient;

    public class ContinuationStack
    {
        private readonly Stack stack;

        public ContinuationStack()
        {
            this.stack = new Stack();
        }

        public bool CanMoveBack()
        {
            if (this.stack.Count >= 2)
                return true;

            return false;
        }

        public bool CanMoveForward()
        {
            return this.GetForwardToken() != null;
        }

        public ResultContinuation GetBackToken()
        {   
            if (this.stack.Count == 0)
                return null;
            // need to pop twice and then return what is left
            this.stack.Pop();
            this.stack.Pop();
            if (this.stack.Count == 0)
                return null;
            return this.stack.Peek() as ResultContinuation;
        }

        public ResultContinuation GetForwardToken()
        {
            if (this.stack.Count == 0)
                return null;

            return this.stack.Peek() as ResultContinuation;
        }

        public void AddToken(ResultContinuation result)
        {
            this.stack.Push(result);
        }
    }
}