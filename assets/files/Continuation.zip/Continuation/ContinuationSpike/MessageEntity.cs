namespace ContinuationSpike
{
    using System;
    using Microsoft.WindowsAzure.StorageClient;

    public class MessageEntity : TableServiceEntity
    {
        public string Text { get; set; }
    }
}