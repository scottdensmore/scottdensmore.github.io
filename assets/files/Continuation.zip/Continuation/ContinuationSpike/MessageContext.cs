namespace ContinuationSpike
{
    using System;
    using System.Globalization;
    using System.Linq;
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;

    public class MessageContext : TableServiceContext
    {
        public const string MessageTable = "Messages";

        public MessageContext(CloudStorageAccount account)
            : this(account.TableEndpoint.ToString(), account.Credentials)
        {
        }

        public MessageContext(string baseAddress, StorageCredentials credentials)
            : base(baseAddress, credentials)
        {
            this.ResolveType = ResolveEntityType;
        }

        public IQueryable<MessageEntity> Messages
        {
            get
            {
                return this.CreateQuery<MessageEntity>(MessageTable);
            }
        }

        private static Type ResolveEntityType(string name)
        {
            var tableName = name.Split(new[] { '.' }).Last();
            switch (tableName)
            {
                case MessageTable:
                    return typeof(MessageEntity);
            }

            throw new ArgumentException(
                string.Format(
                    CultureInfo.InvariantCulture,
                    "Could not resolve the table name '{0}' to a known entity type.",
                    name));
        }
    }
}