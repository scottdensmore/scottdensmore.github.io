﻿namespace ContinuationSpike
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using Microsoft.WindowsAzure.StorageClient;

    public partial class _Default : Page
    {
        private const string StackIndex = "stack";
        private List<MessageEntity> messages;


        public ContinuationStack ContinuationStack
        {
            get
            {
                var stack = (ContinuationStack)Session[StackIndex];
                if (stack == null)
                {
                    stack = new ContinuationStack();
                    Session[StackIndex] = stack;
                }
                return stack;
            }
        }

        private IAsyncResult BeginAsyncOperation(object sender, EventArgs e, AsyncCallback cb, object extradata)
        {
            var query = new MessageContext(CloudConfiguration.GetStorageAccount()).Messages.Take(3).AsTableServiceQuery();
            if (Request["ct"] == "forward")
            {
                var segment = this.ContinuationStack.GetForwardToken();
                return query.BeginExecuteSegmented(segment, cb, query);
            }

            if (Request["ct"] == "back")
            {
                var segment = this.ContinuationStack.GetBackToken();
                return query.BeginExecuteSegmented(segment, cb, query);
            }
            return query.BeginExecuteSegmented(cb, query);
        }

        private static void ClearData()
        {
            var svc = new MessageContext(CloudConfiguration.GetStorageAccount());
            foreach (var entity in svc.Messages)
            {
                svc.DeleteObject(entity);
            }
            svc.SaveChanges();
        }

        private void EndAsyncOperation(IAsyncResult result)
        {
            var cloudTableQuery = result.AsyncState as CloudTableQuery<MessageEntity>;
            ResultSegment<MessageEntity> resultSegment = cloudTableQuery.EndExecuteSegmented(result);
            this.ContinuationStack.AddToken(resultSegment.ContinuationToken);
            this.messages = resultSegment.Results.ToList();
        }

        protected void loadDataButton_Click(object sender, EventArgs e)
        {
            ClearData();
            Session[StackIndex] = null;
            this.nextLink.Visible = true;

            int howmany = Int32.Parse(this.numberBox.Text);

            var svc = new MessageContext(CloudConfiguration.GetStorageAccount());
            for (int i = 0; i < howmany; i++)
            {
                svc.AddObject(MessageContext.MessageTable, new MessageEntity()
                                                               {
                                                                   Text = string.Format("message #{0}", i),
                                                                   PartitionKey = (i/10).ToString("d3"),
                                                                   // partition key is the number up to the last digit (zero-padded to length three)
                                                                   RowKey = (i%10).ToString() // row key is the final digit
                                                               });
            }
            svc.SaveChanges();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            AddOnPreRenderCompleteAsync(
                new BeginEventHandler(this.BeginAsyncOperation),
                new EndEventHandler(this.EndAsyncOperation)
                );
        }

        protected void Page_PreRenderComplete(object sender, EventArgs e)
        {
            this.messageList.DataSource = this.messages;
            this.messageList.DataBind();
            if (this.ContinuationStack.CanMoveForward())
            {
                this.nextLink.NavigateUrl = "?ct=forward";
            }
            else
            {
                this.nextLink.Visible = false;
            }

            if (this.ContinuationStack.CanMoveBack())
            {
                this.backLink.NavigateUrl = "?ct=back";
            }
            else
            {
                this.backLink.Visible = false;
            }
        }
    }
}