﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly : AssemblyTitle("Wcf.Extensions")]
[assembly : AssemblyDescription("")]
[assembly : AssemblyConfiguration("")]
[assembly : AssemblyCompany("")]
[assembly : AssemblyProduct("Wcf.Extensions")]
[assembly : AssemblyCopyright("Copyright ©  2008")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCulture("")]
[assembly : ComVisible(false)]
[assembly : Guid("3058c808-6df1-4687-b030-4c0e017ffc60")]
[assembly : AssemblyVersion("1.0.0.0")]
[assembly : AssemblyFileVersion("1.0.0.0")]