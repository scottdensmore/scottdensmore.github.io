﻿using System;
using System.ServiceModel.Configuration;

namespace Wcf.Extensions
{
    /// <summary>
    /// Represents a configuration element that contains a behavior extension 
    /// which enable the user to customize service or endpoint behaviors to include
    /// the container to use when using the <see cref="FlatWsdlServiceBehavior"/>.
    /// </summary>
    public class FlatWsdlBehaviorExtensionElement : BehaviorExtensionElement
    {
        /// <summary>
        /// Gets the type of behavior.
        /// </summary>
        /// <returns>
        /// A <see cref="FlatWsdlServiceBehavior"/> type.
        /// </returns>
        public override Type BehaviorType
        {
            get { return typeof(FlatWsdlServiceBehavior); }
        }

        /// <summary>
        /// Creates a behavior extension based on the current configuration settings.
        /// </summary>
        /// <returns>
        /// The behavior extension.
        /// </returns>
        protected override object CreateBehavior()
        {
            return new FlatWsdlServiceBehavior();
        }
    }
}