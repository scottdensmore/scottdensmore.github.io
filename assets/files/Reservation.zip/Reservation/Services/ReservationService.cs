﻿using System.ServiceModel;

namespace Services
{
    [ServiceBehavior(Namespace = "http://scottdensmore.com/reservations/2008/09")]
    public class ReservationService : IReservationService
    {
        public string Echo(string param)
        {
            return param;
        }
    }
}