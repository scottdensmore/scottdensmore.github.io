﻿using System.ServiceModel;

namespace Services
{
    [ServiceContract(Namespace = "http://scottdensmore.com/reservations/2008/09", Name = "ReservationService")]
    public interface IReservationService
    {
        [OperationContract(Name = "Echo",
            Action = "EchoRequest",
            ReplyAction = "EchoResponse")]
        string Echo(string param);
    }
}