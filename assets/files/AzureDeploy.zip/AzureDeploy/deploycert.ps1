$cert = Get-Item cert:\CurrentUser\My\EF036446263E7D67F73FFF48372FCF4FF18AB054
$sub = "a3e494d0-a5b0-4b41-b7a6-7f0952471687"
$servicename = $args[0]
$certToDeploy = $args[1]
$certPassword = $args[2]



if ((Get-PSSnapin | ?{$_.Name -eq "AzureManagementToolsSnapIn"}) -eq $null)
{
  Add-PSSnapin AzureManagementToolsSnapIn
}

Add-Certificate -ServiceName $servicename -Certificate $cert -SubscriptionId $sub -CertificateToDeploy $certToDeploy -Password $certPassword